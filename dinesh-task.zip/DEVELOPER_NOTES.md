# 🧑‍💻 Developer Notes

## ✅ Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev
```

---

## 🔧 Vite Config Example

Enable CSS source maps for better debugging during development:

```js
// vite.config.js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  css: {
    devSourcemap: true,
  },
});
```

---

## 🧠 About the Project

This project is a responsive frontend web app built with **React + Vite**. It includes:

* Animated horizontal scroll components
* Smooth scroll-to-top and scroll-to-section buttons
* Reusable UI with TailwindCSS & custom css
* Clean folder structure for scalability
* Accessibility best practices

---

## 👢 Folder Structure (Minimal)

```
src/
├── assets/               # Images, fonts, icons
├── components/           # Reusable components
│   ├── header/
│   ├── workshops/
│   ├── contact/
│   ├── blog/
│   ├── footer/
│   └── ui/               # Buttons, Badges, Cards, etc.
├── App.jsx               # Main app entry
└── main.jsx              # React DOM renderer
```

---

## 🐞 Common Issues & Fixes

### 1. **CSS Source Maps Not Showing in DevTools**

**Cause:** `devSourcemap` not enabled
**Fix:**

```js
// vite.config.js
css: {
  devSourcemap: true
}
```

---
======================================
<!-- used Api and structure -->
### https://dummyjson.com/posts
### {
  "posts": [
    {
      "id": 1,
      "title": "His mother had always taught him",
      "body": "His mother had always taught him not to ever think of himself as better than others. He'd tried to live by this motto. He never looked down on those who were less fortunate or who had less money than him. But the stupidity of the group of people he was talking to made him change his mind.",
      "tags": [
        "history",
        "american",
        "crime"
      ],
      "reactions": {
        "likes": 192,
        "dislikes": 25
      },
      "views": 305,
      "userId": 121
    },
  ]
} ###
=================================================
### 2. **Scroll Animation Too Fast or Choppy**

**Cause:** Native `window.scrollTo` can be too abrupt
**Fix:**
Use a smooth custom scroll function:

```js
const scrollToTop = () => {
  const scrollStep = -window.scrollY / (100 / 5); // adjust speed
  const scrollInterval = setInterval(() => {
    if (window.scrollY !== 0) {
      window.scrollBy(0, scrollStep);
    } else {
      clearInterval(scrollInterval);
    }
  }, 15);
};
```

---
=================================================
### 3. **Hover to Pause Auto Scroll Not Working**

**Fix:**
Apply animation only to the moving element, then pause on hover:

```css
.scroller-track {
  animation: scroll-left 20s linear infinite;
}

.scroller-container:hover .scroller-track {
  animation-play-state: paused;
}
```

---
===================================================

### 4. **Focus Ring (Blue Border) Appears on Click**

**Fix:**
Add `focus:outline-none` and `focus:ring-0` to button class:

```jsx
className="focus:outline-none focus:ring-0"
```

---

## 🚀 Build for Production

```bash
npm run build
```

Preview with:

```bash
npm run preview
```

---
===============================================
## 💡 Tips

* Ensure `public/` folder contains static assets (if needed).
* Use `useEffect` for scroll events to avoid performance issues.
* Test responsiveness across breakpoints (e.g. 320px, 768px, 1024px+).

---

## 📊 Faced Issue & Solution

### 📌 Issue: Blog Section — Debounced Fetching Logic

In the Blog section, the goal was to:

* Fetch blog posts from a mock API (e.g., JSONPlaceholder)
* Initially load the first 10 posts
* Load more posts when a button is clicked or a condition is met
* Avoid multiple fetch triggers from rapid user interaction

### ✅ Solution: **Debounce the Data Fetch**

Instead of scroll-based infinite loading, a **debounce** was added to prevent multiple fetch requests from firing too quickly (e.g., during fast button clicks or quick page switches):

```js
const debounce = (func, delay) => {
  let timeout;
  return (...args) => {
    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), delay);
  };
};
```

Used with a `fetchPosts` function inside a `useEffect` or handler:

```js
const debouncedFetch = useCallback(debounce(() => {
  fetchPosts(); // Actual API call
}, 250), []);
```

### ✅ Result:

* Prevents duplicate data loads
* Reduces unnecessary API calls
* Improves user experience with controlled fetch timing


### AI Usage:

* In the Blog Section, AI-assisted methods were used to:
* Implement debounce for smooth infinite scrolling
* Generate dynamic and user-friendly loading behavior