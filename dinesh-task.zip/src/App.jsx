import React, { useState, useEffect, useRef } from 'react';
import Header from './components/Header/Header';
import Welcome from './components/Welcome/Welcome';
import Portfolio from './components/Portfolio/Portfolio';
import Contact from './components/Contact/Contact';
import Blog from './components/Blog/Blog';
import Together from './components/Together/Together';
import Footer from './components/Footer/footer';
import AOS from 'aos';
import 'aos/dist/aos.css';
import './App.css';
import ScrollToTop from './components/ScrollToTop/ScrollToTop';


function App() {
  const [activeSection, setActiveSection] = useState('welcome');
  const [isLoading, setIsLoading] = useState(true);
  const observerRef = useRef(null);
  const sectionsRef = useRef([]);
 useEffect(() => {
    AOS.init({
      duration: 800,
      easing: 'ease-in-out',
      once: false,
      mirror: true
    });
      // Add this to refresh AOS on initial load
    setTimeout(() => {
      AOS.refresh();
    }, 500);
  }, []);
  
  // Initialize on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
      initializeObserver();
    }, 300); 

    return () => {
      clearTimeout(timer);
      if (observerRef.current) {
        observerRef.current.disconnect();
      }
    };
  }, []);

  const initializeObserver = () => {
    if (observerRef.current) {
      observerRef.current.disconnect();
    }
  
    const options = {
      root: null,
      rootMargin: '-40% 0px -40% 0px', // Adjusted margins
      threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
    };
  
    const observer = new IntersectionObserver((entries) => {
      let mostVisible = { id: activeSection, ratio: 0 };
      
      entries.forEach(entry => {
        if (entry.intersectionRatio > mostVisible.ratio) {
          mostVisible = { id: entry.target.id, ratio: entry.intersectionRatio };
        }
      });
  
      if (mostVisible.ratio > 0) {
        setActiveSection(mostVisible.id);
      }
    }, options);
  
    observerRef.current = observer;
  
    const sections = document.querySelectorAll('section[id]');
    sectionsRef.current = Array.from(sections);
    
    sections.forEach(section => {
      observer.observe(section);
    });
  };
  // Re-initialize observer when sections might change
  useEffect(() => {
    if (!isLoading) {
      const resizeObserver = new ResizeObserver(() => {
        initializeObserver();
      });

      resizeObserver.observe(document.body);
      return () => resizeObserver.disconnect();
    }
  }, [isLoading]);

  if (isLoading) {
    return (
      <div className="loading-screen">
        <div className="loading-spinner"></div>
        
      </div>
    );
  }

  return (
    <div className="App">
      <Header activeSection={activeSection} onSectionClick={setActiveSection} />
      <main>
        <Welcome id="welcome" />
        {/* <Hero /> */}
        <Portfolio id="workshops" />
        {/* <InfiniteScrollCards /> */}
        <Contact id="contact" />
        <Blog id="blog" />
        <Together />
        <Footer />
        <ScrollToTop />
      </main>
    </div>
  );
}

export default App;