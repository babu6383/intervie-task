import React, { useState, useEffect, useRef } from 'react';
import './Header.css';

const Header = ({ activeSection, onSectionClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const observerRef = useRef(null);
  const sectionsRef = useRef([]);

  const navigation = [
    { id: 'welcome', label: 'Home' },
    { id: 'projects', label: 'Workshops' },
    { id: 'contact', label: 'Contact' },
    { id: 'blogg', label: 'Blog' }
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      // Temporarily disable observer
      if (observerRef.current) {
        observerRef.current.disconnect();
      }

      // Scroll to section
      element.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      });

      // Force update active section
      onSectionClick(sectionId);
      setIsMobileMenuOpen(false);

      // Re-enable observer after scroll
      setTimeout(() => {
        if (observerRef.current) {
          sectionsRef.current.forEach(section => {
            observerRef.current.observe(section);
          });
        }
      }, 1000);
    }
  };

  return (
    <header className={`header ${isScrolled ? 'scrolled' : ''}`}>
      <div className="container">
        <nav className="nav">
          <div className="nav-brand">
            <button 
              onClick={() => scrollToSection('welcome')}
              className="brand-link"
              aria-label="Go to homepage"
            >
              <span className="brand-text">L-hub</span>
            </button>
          </div>

          <div className={`nav-menu ${isMobileMenuOpen ? 'open' : ''}`}>
            {navigation.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`nav-link ${activeSection === item.id ? 'active' : ''}`}
                aria-label={`Go to ${item.label} section`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <button
            className="mobile-toggle"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle mobile menu"
            aria-expanded={isMobileMenuOpen}
          >
            <span className={`hamburger ${isMobileMenuOpen ? 'open' : ''}`}>
              <span></span>
              <span></span>
              <span></span>
            </span>
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;