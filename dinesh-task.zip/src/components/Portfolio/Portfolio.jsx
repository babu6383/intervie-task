import { Github, ExternalLink } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../Ui/card";
import { Badge } from "../Ui/badge";
import "./Portfolio.css";
import task1 from "../../assets/task1.webp";
import task2 from "../../assets/task2.webp";

const Portfolio = () => {
  const projects = [
    {
      title: "E-Commerce Platform",
      description: "Full-stack React app with real-time inventory and payment integration.",
      image: task1,
      tech: ["React", "Node.js", "MongoDB", "Stripe"],
      github: "#",
      live: "#",
      status: "In Development",
    },
    {
      title: "Social Media Dashboard",
      description: "Analytics dashboard for social media management.",
      image: task2,
      tech: ["React", "D3.js", "Firebase", "Tailwind"],
      github: "#",
      live: "#",
      status: "70% Complete",
    },
    {
      title: "Task Management App",
      description: "Real-time task collaboration with drag-and-drop.",
      image: task2,
      tech: ["React", "Socket.io", "Express", "PostgreSQL"],
      github: "#",
      live: "#",
      status: "Live",
    },
    {
      title: "Blog CMS",
      description: "Headless blog with markdown editor and admin panel.",
      image: task1,
      tech: ["Next.js", "Sanity", "Tailwind"],
      github: "#",
      live: "#",
      status: "Beta",
    },
  ];

  const repeatedProjects = [...projects, ...projects]; // for smooth looping

  return (
    <section id="projects" className="py-20 px-4 bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="mx-auto">
       
        <div className="text-center mb-12">
            
          <h2 className="text-5xl font-extrabold text-gray-900 mb-4 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent portfolio-title">
            Workshops
          </h2>
          <p className="section-description">
            A showcase of my web development journey featuring React and JavaScript applications
          </p>
        </div>
<div className=" container scroller-container">
  <div className="scrolling-wrapper">
    {repeatedProjects.map((project, index) => (
      <Card
        key={`${project.title}-${index}`}
        className=" portfolio-cards mx-2 flex-shrink-0 group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 overflow-hidden
         "
      >
                <div className="relative bg-gray-100 flex items-center justify-center h-48 overflow-hidden">
                  {project.image ? (
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  ) : (
                    <div className="text-gray-400">No Image</div>
                  )}
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-white text-xs  border border-gray-300 shadow">
                      {project.status}
                    </Badge>
                  </div>
                </div>

                <CardHeader>
                  <CardTitle className="text-lg font-semibold text-gray-900">{project.title}</CardTitle>
                  <CardDescription className="text-sm text-gray-600">{project.description}</CardDescription>
                </CardHeader>

                <CardContent>
                  <div className="flex flex-wrap gap-2 mb-2 mt-2">
                    {project.tech.map((tech) => (
                      <Badge key={tech} className="text-xs bg-gray-200 text-gray-700 rounded-md px-2 py-1 portfolio-badge">
                        {tech}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex gap-2 mt-4">
                    <a
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-2 border border-gray-300 rounded-md px-4 py-2 text-sm text-gray-800 hover:bg-gray-100 transition"
                    >
                      <Github size={16} />
                      Code
                    </a>
                    <a
                      href={project.live}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 inline-flex items-center justify-center gap-2 bg-gray-900 text-white rounded-md px-4 py-2 text-sm hover:bg-gray-800 transition"
                    >
                      <ExternalLink size={16} />
                      Live Demo
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
