function Badge({ className = "", variant = "default", ...props }) {
    const variants = {
        default: "bg-gray-900   dark:text-gray-900",
        secondary: "bg-gray-100 text-gray-900 dark:bg-gray-800 dark:text-gray-100",
        outline: "border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100",
    }

    return (
        <div
            className={` badge inline-flex bg-gray-950/5  items-center rounded-xl border  px-2 py-0.5 text-xs font-semibold transition-colors ${variants[variant]} ${className}`}
            {...props}
        />
    )
}

export { Badge }
