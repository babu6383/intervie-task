"use client";
import { useState, useEffect, useCallback } from "react";
import {
  Loader2,
  XCircle,
  Calendar,
  Clock,
  User,
  Sparkles,
  ExternalLink,
  ThumbsUp, 
  ThumbsDown, 
  Eye, 
  Tag,  
} from "lucide-react";
import axios from "axios";
import blog from "../../assets/blog.png";
import task2 from "../../assets/task2.webp";

// Network check
const checkOnlineStatus = async () => {
  try {
    const online = await fetch("https://httpbin.org/get", {
      method: "HEAD",
      cache: "no-store",
    });
    return online.status >= 200 && online.status < 300;
  } catch {
    return false;
  }
};

// Retry helper
const fetchWithRetry = async (url, options = {}, retries = 3, backoff = 300) => {
  try {
    return await axios.get(url, {
      timeout: 10000,
      params: options.params || {},
    });
  } catch (err) {
    if (retries <= 0) throw err;
    await new Promise((resolve) => setTimeout(resolve, backoff));
    return fetchWithRetry(url, options, retries - 1, backoff * 2);
  }
};

// Fallback
const generateFallbackData = (pageNum, count = 10) => {
  return Array(count)
    .fill(0)
    .map((_, i) => ({
      id: i + 1 + (pageNum - 1) * count,
      title: `Sample Post ${i + 1 + (pageNum - 1) * count}`,
      body: `This is sample content for post ${i + 1}. Lorem ipsum dolor sit amet.`,
      userId: 1,
    }));
};

const Blog = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const MAX_POSTS = 30;

  const debounce = useCallback((func, wait) => {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }, []);

  const transformPost = (post) => {
    return {
      ...post,
      excerpt: post.body.substring(0, 150) + "...",
      readTime: Math.ceil(post.body.split(" ").length / 200),
      publishedAt: new Date(
        Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000
      ).toISOString(),
      imageUrl: task2,
      authorName: post.userId ? `User ${post.userId}` : "Our Team",
      authorRole: "Content Creator",
      authorAvatar: blog,
      likes: post.reactions?.likes || 0,
      dislikes: post.reactions?.dislikes || 0,
      views: post.views || 0,
      tags: post.tags || []
    };
  };

  const fetchPosts = async (pageNum, reset = false) => {
    if (loading) return;
    if (!reset && posts.length >= MAX_POSTS) {
      setHasMore(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const isOnline = await checkOnlineStatus();
      if (!isOnline) {
        throw new Error("offline");
      }

      const response = await fetchWithRetry("https://dummyjson.com/posts", {
        params: { limit: 10, skip: (pageNum - 1) * 10 },
      });

      const newPosts = response.data.posts;

      if (newPosts.length === 0) {
        setHasMore(false);
      } else {
        const transformedPosts = newPosts.map(transformPost);
        setPosts((prev) => {
          const updatedPosts = reset
            ? transformedPosts
            : [...prev, ...transformedPosts];
          if (updatedPosts.length >= MAX_POSTS) {
            setHasMore(false);
            return updatedPosts.slice(0, MAX_POSTS);
          }
          return updatedPosts;
        });
      }
    } catch (err) {
      console.error("Fetch error:", err);
      if (err.message === "offline") {
        setError("You appear to be offline. Please check your connection.");
      } else {
        const fallbackData = generateFallbackData(pageNum);
        const transformedPosts = fallbackData.map(transformPost);
        setPosts((prev) => (reset ? transformedPosts : [...prev, ...transformedPosts]));
        setError("Using sample data as API is unavailable");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleScroll = useCallback(
    debounce(() => {
      if (loading || !hasMore || posts.length >= MAX_POSTS) return;

      const scrollTop = window.pageYOffset;
      const windowHeight = window.innerHeight;
      const docHeight = document.documentElement.scrollHeight;

      if (scrollTop + windowHeight >= docHeight - 500) {
        setPage((prev) => prev + 1);
      }
    }, 250),
    [loading, hasMore, posts.length]
  );

  useEffect(() => {
    fetchPosts(1, true);
  }, []);

  useEffect(() => {
    if (page > 1) {
      fetchPosts(page);
    }
  }, [page]);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const handleRetry = () => {
    setError(null);
    setPage(1);
    setPosts([]);
    setHasMore(true);
    fetchPosts(1, true);
  };

  const featuredPost = posts.length > 0 ? posts[0] : null;
  const remainingPosts = posts.length > 1 ? posts.slice(1) : [];

  return (
    <section id="blogg" className="relative min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 py-16 overflow-hidden"
    >
      <div className=" absolute inset-0 bg-[radial-gradient(circle_at_10%_90%,rgba(59,130,246,0.05),transparent_50%),radial-gradient(circle_at_90%_10%,rgba(139,92,246,0.05),transparent_50%)] z-0"></div>
      <div className=" mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-extrabold text-gray-900 mb-4 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
            Latest Blog Posts
          </h2>
          <p className="section-description">
            Insights, tutorials, and thoughts on web development, design, and technology.
          </p>
        </div>

        {/* Featured */}
        {featuredPost && (
          <article className="mb-16 bg-white border rounded-lg overflow-hidden flex flex-col lg:flex-row transform transition-transform duration-300 hover:scale-[1.005] hover:shadow-3xl animate-fade-in-up">
            <div className="lg:w-1/2 h-96 lg:h-auto overflow-hidden relative">
              <img
                src={featuredPost.imageUrl}
                alt={featuredPost.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.src = "/placeholder.svg";
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
              <div className="absolute top-4 left-4 px-3 py-1 bg-blue-600 text-white text-sm font-semibold rounded-full flex items-center gap-1">
                <Sparkles size={14} /> Featured
              </div>
            </div>
            <div className="lg:w-1/2 p-8 lg:p-12 flex flex-col justify-center">
              <div className="flex items-center text-gray-500 text-sm mb-4 space-x-4">
                <span className="flex items-center gap-1">
                  <Calendar size={16} className="text-blue-500" />
                  {formatDate(featuredPost.publishedAt)}
                </span>
                <span className="flex items-center gap-1">
                  <Clock size={16} className="text-blue-500" />
                  {featuredPost.readTime} min read
                </span>
                <span className="flex items-center gap-1">
                  <User size={16} className="text-blue-500" />
                  {featuredPost.authorName}
                </span>
              </div>
              <h3 className="text-4xl font-bold text-gray-900 mb-4 leading-tight">
                {featuredPost.title}
              </h3>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                {featuredPost.excerpt}
              </p>
              
              {/* Featured Post Metrics */}
              <div className="flex flex-wrap items-center gap-4 mb-6">
                {/* Likes */}
                <div className="flex items-center gap-1.5 bg-green-50 px-3 py-1.5 rounded-full text-sm text-green-800">
                  <ThumbsUp className="w-4 h-4" />
                  <span>{featuredPost.likes}</span>
                </div>
                
                {/* Dislikes */}
                <div className="flex items-center gap-1.5 bg-red-50 px-3 py-1.5 rounded-full text-sm text-red-800">
                  <ThumbsDown className="w-4 h-4" />
                  <span>{featuredPost.dislikes}</span>
                </div>
                
                {/* Views */}
                <div className="flex items-center gap-1.5 bg-blue-50 px-3 py-1.5 rounded-full text-sm text-blue-800">
                  <Eye className="w-4 h-4" />
                  <span>{featuredPost.views}</span>
                </div>
              </div>

              {/* Featured Post Tags */}
              {featuredPost.tags.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 mb-6">
                  <Tag className="w-4 h-4 text-gray-500" />
                  {featuredPost.tags.map(tag => (
                    <span 
                      key={tag} 
                      className="px-2.5 py-1 bg-gray-100 text-gray-800 text-xs rounded-full capitalize flex items-center gap-1"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              <div className="w-40">
                <a
                  href="#" // Placeholder link
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-gray-900 text-white rounded-md px-4 py-2 hover:text-white text-sm hover:bg-gray-800 transition"
                >
                  <ExternalLink size={16} />
                  Read More
                </a>
              </div>
            </div>
          </article>
        )}

        {/* Grid */}
        {remainingPosts.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-8">
            {remainingPosts.map((post) => (
              <article
                key={post.id}
                className="bg-white border rounded-lg overflow-hidden transform transition-transform duration-300 hover:scale-[1.02] hover:shadow-xl animate-fade-in-up"
              >
                <div className="h-52 overflow-hidden">
                  <img
                    src={post.imageUrl}
                    alt={post.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.target.src = "/placeholder.svg";
                    }}
                  />
                </div>
                <div className="p-6 flex flex-col flex-grow">
                  <div className="flex items-center text-gray-500 text-sm mb-3 space-x-2">
                    <span className="flex items-center gap-1">
                      <Calendar size={14} className="text-blue-500" />
                      {formatDate(post.publishedAt)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock size={14} className="text-blue-500" />
                      {post.readTime} min read
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{post.title}</h3>
                  <p className="text-gray-700 text-base mb-4 flex-grow">{post.excerpt}</p>
                  
                  {/* Grid Post Metrics */}
                  <div className="flex flex-wrap items-center gap-3 mb-3">
                    {/* Likes */}
                    <div className="flex items-center gap-1 text-xs text-green-600">
                      <ThumbsUp className="w-3.5 h-3.5" />
                      <span>{post.likes}</span>
                    </div>
                    
                    {/* Dislikes */}
                    <div className="flex items-center gap-1 text-xs text-red-600">
                      <ThumbsDown className="w-3.5 h-3.5" />
                      <span>{post.dislikes}</span>
                    </div>
                    
                    {/* Views */}
                    <div className="flex items-center gap-1 text-xs text-blue-600">
                      <Eye className="w-3.5 h-3.5" />
                      <span>{post.views}</span>
                    </div>
                  </div>

                  {/* Grid Post Tags */}
                  {post.tags.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 mb-3 text-xs">
                      <Tag className="w-3 h-3 text-gray-400" />
                      {post.tags.slice(0, 2).map(tag => (
                        <span 
                          key={tag} 
                          className="px-2 py-0.5 bg-gray-100 text-gray-800 rounded-full capitalize flex items-center gap-1"
                        >
                          {tag}
                        </span>
                      ))}
                      {post.tags.length > 2 && (
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-800 rounded-full flex items-center gap-1">
                          +{post.tags.length - 2}
                        </span>
                      )}
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-4 border-t border-gray-200">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-blue-200">
                        <img
                          src={post.authorAvatar}
                          alt="Author"
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            e.target.src = "/placeholder.svg";
                          }}
                        />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-sm font-semibold text-gray-900">
                          {post.authorName}
                        </span>
                        <span className="text-xs text-gray-600">{post.authorRole}</span>
                      </div>
                    </div>
                    <a
                      href="#"
                      className="inline-flex items-center gap-2 bg-gray-900 text-white rounded-md px-4 py-2 text-sm hover:bg-gray-800"
                    >
                      <ExternalLink size={16} />
                      Read More
                    </a>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* Loading & End */}
        {loading && (
          <div className="flex justify-center py-12 text-gray-600">
            <div className="inline-flex items-center space-x-4 bg-white rounded-2xl px-8 py-4 shadow-lg">
              <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
              <span className="text-gray-800 font-semibold text-lg">Loading...</span>
            </div>
          </div>
        )}
        {error && posts.length > 0 && (
          <div className="flex items-center justify-center gap-4 bg-red-50 text-red-700 p-4 rounded-lg border border-red-200 mt-8">
            <span>{error}</span>
            <button
              onClick={handleRetry}
              className="text-red-700 font-semibold underline hover:text-red-900"
            >
              Retry
            </button>
          </div>
        )}
        {!hasMore && posts.length >= MAX_POSTS && (
          <div className="text-center py-12 text-gray-700">
            <p className="text-xl font-medium mb-6">
              You've reached the end of our blog posts!
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default Blog;