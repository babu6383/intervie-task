"use client"

import { useState, useEffect } from "react"
import "./Welcome.css"
import herobanner from "../../assets/mahila2.png"
import { Github, ExternalLink, Lightbulb ,ArrowRight,Zap} from "lucide-react"

const Welcome = () => {
  const [isVisible, setIsVisible] = useState(false)
  const [currentFeature, setCurrentFeature] = useState(0)

  const features = ["Lightning Fast", "Secure & Reliable", "Scalable Solutions"]

  useEffect(() => {
    setIsVisible(true)

    const featureInterval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length)
    }, 3000)

    return () => clearInterval(featureInterval)
  }, [])

  const scrollToFeatures = () => {
    document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })
  }

  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section id="welcome" className="welcome">
      <div className="welcome-inner">

         <div className=" inset-0 overflow-hidden">
        {/* Floating Orbs */}
        {/* <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-gradient-to-r from-purple-400/30 to-pink-400/30 rounded-full mix-blend-multiply filter blur-xl animate-blob"></div>
        <div className="absolute top-1/3 right-1/4 w-72 h-72 bg-gradient-to-r from-yellow-400/30 to-red-400/30 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-gradient-to-r from-blue-400/30 to-green-400/30 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000"></div> */}

        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]"></div>

        {/* Gradient Mesh */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/5 to-transparent"></div>
      </div>
      <div className="welcome-bg">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]"></div>
        <div className="grid-overlay"></div>
      </div>

    <div 
  className="welcome-container"
  data-aos="fade-up"
  data-aos-duration="800"
>
  <div className="welcome-content">
    <div 
      className={`welcome-text ${isVisible ? "visible" : ""}`}
      data-aos="fade-right"
      data-aos-delay="200"
      data-aos-duration="800"
    >
      <div 
        className="badge"
        data-aos="fade-down"
        data-aos-delay="100"
      >
        <span className="badge-icon"><Lightbulb className="w-4 h-4 text-yellow-500" /></span>
        Learn & Build Zone
      </div>

      <h1 
        className="text-2xl sm:text-2xl md:text-6xl lg:text-5xl xl:text-7xl font-black leading-[0.9] tracking-tight welcome-text"
        data-aos="fade-up"
        data-aos-delay="300"
      >
        <span className="block text-gray-900">Welcome To My</span>
        <span className="block bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent animate-gradient-x">
          Learning Hub
        </span>
      </h1>

      {/* Dynamic Feature Text */}
      <div 
        className="relative"
        data-aos="fade-up"
        data-aos-delay="400"
      >
        <div className="text-xs sm:text-2xl md:text-3xl lg:text-2xl font-bold flex sm:flex-row items-center lg:justify-start sm:justify-center gap-3 min-h-[3rem]">
          <span className="text-gray-600 flex items-center gap-2">
            <Zap className="w-6 h-6 text-yellow-500" />
            Experience
          </span>
          <div className="relative overflow-hidden">
            <span
              key={currentFeature}
              className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 animate-slide-up font-extrabold"
            >
              {features[currentFeature]}
            </span>
          </div>
        </div>
      </div>

      <p 
        className="welcome-description sm:justify-center"
        data-aos="fade-up"
        data-aos-delay="500"
      >
        Transform your ideas into reality with our cutting-edge platform. Built for modern teams who demand
        excellence, speed, and reliability in everything they create.
      </p>

      {/* CTA Buttons */}
      <div 
        className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-4"
        
      >
        <a
          href="#"
          className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 bg-white border-2 border-gray-300 rounded-2xl text-base font-semibold text-gray-800 hover:border-gray-400 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-blue-500/20"
        >
          <Github className="w-5 h-5 group-hover:rotate-12 " />
          <span>My Codes</span>
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-600/0 to-purple-600/0 group-hover:from-blue-600/5 group-hover:to-purple-600/5 transition-all duration-300"></div>
        </a>

        <a
          href="#"
          className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-gray-900 to-gray-800 text-white rounded-2xl text-base font-semibold hover:from-gray-800 hover:to-gray-700 transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-gray-500/20"
        >
          <ExternalLink className="w-5 h-5 group-hover:rotate-12 " />
          <span>Projects</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-600/0 to-purple-600/0 group-hover:from-blue-600/20 group-hover:to-purple-600/20 transition-all duration-300"></div>
        </a>
      </div>
    </div>

    <div 
      className={`welcome-visual ${isVisible ? "visible" : ""}`}
      data-aos="fade-left"
      data-aos-delay="700"
    >
      <div className="visual-container">
        <div className="main-card">
          <img src={herobanner} alt="" />
        </div>
      </div>
    </div>
  </div>

  <div
    className="scroll-indicator"
    onClick={() => {
      const el = document.getElementById('projects');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }}
    role="button"
    tabIndex={0}
    onKeyDown={(e) => {
      if (e.key === 'Enter') {
        const el = document.getElementById('projects');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }
    }}
   
  >
    <div className="scroll-mouse">
      <div className="scroll-wheel"></div>
    </div>
    <span>Scroll More</span>
  </div>
</div>
      </div>
    </section>
  )
}

export default Welcome
