"use client"

import { Mail, Github, Linkedin, Twitter, Headset } from "lucide-react"
import { Button } from "../../components/Ui/button"
import "./Together.css"

export default function Together() {
    return (
        <div
            id="contact"
            className="py-10 px-4 pb-5 bg-gradient-to-br from-blue-100 via-indigo-100 to-pink-100 together"
        >
            <div className="max-w-4xl mx-auto text-center">
                <h2 className="text-5xl font-extrabold text-gray-900 mb-4 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                    Let's Work Together
                </h2>

                <p className="text-xl text-gray-700 mb-12 max-w-2xl mx-auto">
                    Ready to bring your ideas to life? I'm always excited to work on new projects and collaborate with amazing people.
                </p>

                <div className="flex flex-col sm:flex-row gap-6 justify-center mb-12">
                    <Button
                        size="lg"
                        className="bg-indigo-600 text-white hover:bg-indigo-700 px-8 py-3"
                        onClick={() => {
                            window.location.href = "mailto:dineshbabu1748@gmail.com?subject=Inquiry&body=Hi there,";
                        }}
                    >
                        <Mail className="w-5 h-5 mr-2" />
                        Send Email
                    </Button>

                    <Button
                        size="lg"
                        className="text-gray-800 hover:bg-gray-100 transition px-8 py-3"
                        onClick={() => {
                            window.location.href = "tel:+916383091748";
                        }}
                    >
                        <Headset className="w-5 h-5 mr-2" />
                        Call Now
                    </Button>
                </div>

                <div className="flex justify-center space-x-6">
                    <a href="#" className="text-gray-700 hover:text-indigo-600 transition-colors">
                        <Github className="w-8 h-8" />
                    </a>
                    <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors">
                        <Linkedin className="w-8 h-8" />
                    </a>
                    <a href="#" className="text-gray-700 hover:text-sky-500 transition-colors">
                        <Twitter className="w-8 h-8" />
                    </a>
                </div>
            </div>
        </div>
    )
}
