"use client"

export default function Footer() {
    return (
        <footer className="py-5 px-4 bg-gray-900 text-white text-center">
            <p className="text-gray-400">© 2025 Learning Hub . Built with React.</p>
        </footer>
    )
}
