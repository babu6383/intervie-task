"use client"

import { useState, useEffect } from "react"
import { Modal, message } from "antd"
import {
  MapPin,
  Mail,
  Phone,
  Linkedin,
  Github,
  Twitter,
  RefreshCw,
  Send,
  CheckCircle,
  XCircle,
  User,
  MessageSquare,
  FileText,
} from "lucide-react"
import "./Contact.css"

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [errors, setErrors] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [captcha, setCaptcha] = useState({ question: "", answer: 0 })
  const [captchaInput, setCaptchaInput] = useState("")

  // Generate math CAPTCHA
  const generateCaptcha = () => {
    const num1 = Math.floor(Math.random() * 10) + 1
    const num2 = Math.floor(Math.random() * 10) + 1
    const operators = ["+", "-", "*"]
    const operator = operators[Math.floor(Math.random() * operators.length)]

    let answer
    let question

    switch (operator) {
      case "+":
        answer = num1 + num2
        question = `${num1} + ${num2}`
        break
      case "-":
        answer = Math.max(num1, num2) - Math.min(num1, num2)
        question = `${Math.max(num1, num2)} - ${Math.min(num1, num2)}`
        break
      case "*":
        const smallNum1 = Math.floor(Math.random() * 5) + 1
        const smallNum2 = Math.floor(Math.random() * 5) + 1
        answer = smallNum1 * smallNum2
        question = `${smallNum1} × ${smallNum2}`
        break
      default:
        answer = num1 + num2
        question = `${num1} + ${num2}`
    }

    setCaptcha({ question, answer })
  }

  useEffect(() => {
    generateCaptcha()
  }, [])

  const validateField = (name, value) => {
    switch (name) {
      case "name":
        if (!value.trim()) return "Name is required"
        if (value.length < 2) return "Name must be at least 2 characters"
        if (!/^[a-zA-Z\s]+$/.test(value)) return "Name can only contain letters and spaces"
        return ""

      case "email":
        if (!value) return "Email is required"
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        if (!emailRegex.test(value)) return "Please enter a valid email address"
        return ""

      case "subject":
        if (!value.trim()) return "Subject is required"
        if (value.length < 5) return "Subject must be at least 5 characters"
        return ""

      case "message":
        if (!value.trim()) return "Message is required"
        if (value.length < 10) return "Message must be at least 10 characters"
        return ""

      default:
        return ""
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }))
    }
  }

  const handleBlur = (e) => {
    const { name, value } = e.target
    const error = validateField(name, value)
    setErrors((prev) => ({ ...prev, [name]: error }))
  }

  const validateForm = () => {
    const newErrors = {}

    Object.keys(formData).forEach((key) => {
      const error = validateField(key, formData[key])
      if (error) newErrors[key] = error
    })

    // Validate CAPTCHA
    if (Number.parseInt(captchaInput) !== captcha.answer) {
      newErrors.captcha = "Incorrect answer. Please try again."
    }

    return newErrors
  }

  const showSuccessModal = () => {
    Modal.success({
      title: "Message Sent Successfully!",
      content: (
        <div className="modal-content success">
          <CheckCircle className="modal-icon" size={48} />
          <p>Thank you for reaching out! We'll get back to you within 24 hours.</p>
        </div>
      ),
      okText: "Great!",
      centered: true,
      className: "custom-ant-modal",
    })
  }

  const showErrorModal = () => {
    Modal.error({
      title: "Oops! Something went wrong",
      content: (
        <div className="modal-content error">
          <XCircle className="modal-icon" size={48} />
          <p>We couldn't send your message. Please try again or contact us directly.</p>
        </div>
      ),
      okText: "Try Again",
      centered: true,
      className: "custom-ant-modal",
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    const formErrors = validateForm()
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors)
      message.warning("Please fix the errors before submitting")
      return
    }

    setIsSubmitting(true)
    setErrors({})

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      message.success({
        content: "Message sent successfully!",
        duration: 3, // seconds
      })


      setFormData({ name: "", email: "", subject: "", message: "" })
      setCaptchaInput("")
      generateCaptcha()
    } catch (error) {
      showErrorModal()
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <section id="contact" className="contact section-padding">
   <div className="custom-shape-divider-top-1753854487">
    <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
        <rect x="1200" height="3.6"></rect>
        <rect height="3.6"></rect>
        <path d="M0,0V3.6H580.08c11,0,19.92,5.09,19.92,13.2,0-8.14,8.88-13.2,19.92-13.2H1200V0Z" className="shape-fill"></path>
    </svg>
</div>
      <div className="container">
        <div className="contact-header">
          <div className="header-badge">
            <Mail className="badge-icon" size={16} />
            <span>Get In Touch</span>
          </div>
          <h2 className="text-5xl font-extrabold text-gray-900 mb-4 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
  Let's Connect With Us
</h2>
<p className="section-description">
  Ready to bring your ideas to life? Let's discuss your project and create something amazing together.
</p>
        </div>

        <div className="contact-content">
          <div className="contact-info">
            <div className="info-cards">
              <div className="info-card">
                <div className="info-icon">
                  <MapPin size={24} />
                </div>
                <div className="info-content">
                  <h3>Location</h3>
                  <p>Tambaram - East</p>
                  <span className="info-subtitle">Available for remote work</span>
                </div>
              </div>

              <div className="info-card">
                <div className="info-icon">
                  <Mail size={24} />
                </div>
                <div className="info-content">
                  <h3>Email</h3>
                  <p>dineshbabu1748@gmail.com</p>
                  <span className="info-subtitle">Response within 24 hours</span>
                </div>
              </div>

              <div className="info-card">
                <div className="info-icon">
                  <Phone size={24} />
                </div>
                <div className="info-content">
                  <h3>Phone</h3>
                  <p>+91 6383-0917-48</p>
                  <span className="info-subtitle">Mon-Fri, 9AM-6PM </span>
                </div>
              </div>
            </div>

            <div className="social-section">
              <h3>Connect With Us</h3>
              <div className="social-links">
                <a href="#" className="social-link" aria-label="LinkedIn">
                  <Linkedin size={20} />
                </a>
                <a href="#" className="social-link" aria-label="GitHub">
                  <Github size={20} />
                </a>
                <a href="#" className="social-link" aria-label="Twitter">
                  <Twitter size={20} />
                </a>
              </div>
            </div>
          </div>

          <div className="contact-form-container">
            <form className="contact-form" onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="name" className="form-label">
                    <User size={16} />
                    Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    className={`form-input ${errors.name ? "error" : ""}`}
                    placeholder="Your full name"
                  />
                  {errors.name && <span className="form-error">{errors.name}</span>}
                </div>

                <div className="form-group">
                  <label htmlFor="email" className="form-label">
                    <Mail size={16} />
                    Email *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    className={`form-input ${errors.email ? "error" : ""}`}
                    placeholder="your.email@example.com"
                  />
                  {errors.email && <span className="form-error">{errors.email}</span>}
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="subject" className="form-label">
                  <FileText size={16} />
                  Subject *
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  onBlur={handleBlur}
                  className={`form-input ${errors.subject ? "error" : ""}`}
                  placeholder="What's this about?"
                />
                {errors.subject && <span className="form-error">{errors.subject}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="message" className="form-label">
                  <MessageSquare size={16} />
                  Message *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  onBlur={handleBlur}
                  className={`form-textarea ${errors.message ? "error" : ""}`}
                  placeholder="Tell us about your project, ideas, or just say hello!"
                  rows="5"
                ></textarea>
                {errors.message && <span className="form-error">{errors.message}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="captcha" className="form-label">
                  Security Check: What is {captcha.question}? *
                </label>
                <div className="captcha-container">
                  <input
                    type="number"
                    id="captcha"
                    value={captchaInput}
                    onChange={(e) => setCaptchaInput(e.target.value)}
                    className={`form-input captcha-input ${errors.captcha ? "error" : ""}`}
                    placeholder="Answer"
                  />
                  <button
                    type="button"
                    onClick={generateCaptcha}
                    className="captcha-refresh"
                    aria-label="Generate new math problem"
                  >
                    <RefreshCw size={16} />
                  </button>
                </div>
                {errors.captcha && <span className="form-error">{errors.captcha}</span>}
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className={`form-submit ${isSubmitting ? "loading" : ""}`}
              >
                {isSubmitting ? (
                  <>
                    <div className="spinner" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send size={18} />
                    Send Message
                  </>
                )}
              </button>

            </form>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
